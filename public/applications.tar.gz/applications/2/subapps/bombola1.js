var app = angular.module("ApioApplicationLog", ["apioProperty"]);
app.controller("defaultController", ["$scope", "currentObject", "socket", function($scope, currentObject, socket){
    console.log("Sono il defaultController e l'oggetto è");
    console.log(currentObject.get());
    $scope.object = currentObject.get();

    $scope.isMobile = window.innerWidth < 768;

    $scope.back = function(){
        $("#ApioApplicationLog").remove();
        Apio.newWidth -= Apio.appWidth;
        $("#ApioApplicationContainer").css("width", Apio.newWidth+"px");
    };
    
}]);

setTimeout(function(){
    angular.bootstrap(document.getElementById("ApioApplicationLog"), ["ApioApplicationLog"]);
},10);
