var app = angular.module("ApioApplication3", ["apioProperty"]);
app.controller("defaultController", ["$scope", "currentObject", "$http", "$window", function ($scope, currentObject, $http, $window) {
    console.log("Sono il defaultController e l'oggetto è");
    console.log(currentObject.get());
    $scope.object = currentObject.get();

    var interval = setInterval(function () {
        var node = document.getElementById("registra_statoinput");
        if (node) {
            node.parentNode.removeChild(node);
            clearInterval(interval);
        }
    }, 50);

    var getMaximumInstallation = function () {
        var max = 0;
        for (var k in $scope.object.properties) {
            var m = Number(k.substr(3));
            if (Object.keys($scope.object.properties[k]).length === 0) {
                return m - 1;
            } else if (m > max) {
                max = m;
            }
        }

        return max;
    };

    $scope.newInstallationFlag = false;
    $scope.newIP = "";
    $scope.newName = "";

    $scope.cancelInstallation = function () {
        $scope.newInstallationFlag = false;
    };

    $scope.changeIP = function (key, val) {
        currentObject.update(key, val);
    };

    $scope.deleteInstallation = function (key, name) {
        alert("key = " + key + ", name = " + name);
        var node = document.getElementById(key);
        node.parentNode.removeChild(node);

        $http.get("/apio/database/getObjects").success(function (data) {
            for (var i in data) {
                if (data[i].name === name) {
                    var removeId = data[i].objectId;
                    break;
                }
            }

            $http.post("/apio/app/delete", {id: removeId}).success(function (data) {
                currentObject.update(key, []);
                alert("Oggetto eliminato con successo");
                $window.location.reload();
            }).error(function (error) {
                console.log("An error has occurred while deleting the app with objectId " + removeId + ": ", error);
            });
        }).error(function (error) {
            console.log("An error has occurred while getting all objects: ", error);
        });
    };

    $scope.newInstallation = function () {
        currentObject.update("imp" + (getMaximumInstallation() + 1), [$scope.newName, $scope.newIP]);
        $http.post("/apio/app/maximumId").success(function (data) {
            var newId = String(Number(data) + 1);
            var dao = {
                address: newId,
                functions: {},
                objectId: newId,
                objectName: $scope.newName,
                pins: {},
                properties: {
                    installation_date: {
                        label: "Data installazione",
                        type: "Text"
                    },
                    kwp: {
                        label: "KWp",
                        type: "Text"
                    },
                    instat_power: {
                        label: "Potenza Instantanea",
                        type: "AsyncDisplay"
                    },
                    day_production: {
                        label: "Produzione da inizio giornata",
                        type: "AsyncDisplay"
                    },
                    total_production: {
                        label: "Produzione totale",
                        type: "AsyncDisplay"
                    },
                    oil_litres_spare: {
                        label: "Litri di petrolio evitati",
                        type: "AsyncDisplay"
                    },
                    co2_emissions_spare: {
                        label: "Emissioni di CO2 evitate",
                        type: "AsyncDisplay"
                    },
                    equivalent_trees: {
                        label: "Alberi equivalenti",
                        type: "AsyncDisplay"
                    },
                    irradiance: {
                        label: "Irradianza",
                        type: "AsyncDisplay"
                    },
                    temperature: {
                        label: "Temperatura",
                        type: "AsyncDisplay"
                    },
                    wind: {
                        label: "Vento",
                        type: "AsyncDisplay"
                    },
                    energy: {
                        label: "Energia",
                        type: "AsyncDisplay"
                    }
                },
                protocol: "l",
                variables: {}
            };

            var ino = "#include \"apioGeneral.h\"\n#include \"atmegarfr2.h\"\n#include \"config.h\"\n#include \"hal.h\"\n#include \"halTimer.h\"\n#include \"nwk.h\"\n#include \"nwkCommand.h\"\n#include \"nwkDataReq.h\"\n#include \"nwkFrame.h\"\n#include \"nwkGroup.h\"\n#include \"nwkRoute.h\"\n#include \"nwkRouteDiscovery.h\"\n#include \"nwkRx.h\"\n#include \"nwkSecurity.h\"\n#include \"nwkTx.h\"\n#include \"phy.h\"\n#include \"sys.h\"\n#include \"sysConfig.h\"\n#include \"sysEncrypt.h\"\n#include \"sysTimer.h\"\n#include \"sysTypes.h\"\n#include \"ApioLwm.h\"\n\nvoid setup() {\n\tgeneralSetup();\n\tapioSetup(" + newId + ");\n\tapioSend(\"" + newId + ":hi::-\");\n}\n\nvoid loop(){\n\tapioLoop();\n\tif(property==\"kwp\"){\n\t\t//Do Something\n\t}\n\tif(property==\"instat_power\"){\n\t\t//Do Something\n\t}\n\tif(property==\"day_production\"){\n\t\t//Do Something\n\t}\n\tif(property==\"total_production\"){\n\t\t//Do Something\n\t}\n\tif(property==\"installation_date\"){\n\t\t//Do Something\n\t}\n\tif(property==\"oil_litres_spare\"){\n\t\t//Do Something\n\t}\n\tif(property==\"co2_emissions_spare\"){\n\t\t//Do Something\n\t}\n\tif(property==\"equivalent_trees\"){\n\t\t//Do Something\n\t}\n\tif(property==\"irradiance\"){\n\t\t//Do Something\n\t}\n\tif(property==\"temperature\"){\n\t\t//Do Something\n\t}\n\tif(property==\"wind\"){\n\t\t//Do Something\n\t}\n\tif(property==\"energy\"){\n\t\t//Do Something\n\t}\n\tproperty = \"\";\n}";
            var html = "<div id=\"ApioApplication" + newId + "\" ng-app=\"ApioApplication" + newId + "\" style=\"padding: 10px;\">\n\t<div ng-controller=\"defaultController\">\n\t\t<topappapplication></topappapplication>\n\t\t<div id=\"app\" style=\"display: block; width: 40%;\">\n\t\t\t<text propertyname=\"installation_date\" label=\"Data installazione\"></text>\n\t\t\t<text propertyname=\"kwp\" label=\"KWp\"></text>\n\t\t\t<asyncdisplay propertyname=\"instat_power\" label=\"Potenza Instantanea\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"day_production\" label=\"Produzione da inizio giornata\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"total_production\" label=\"Produzione totale\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"oil_litres_spare\" label=\"Litri di petrolio evitati\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"co2_emissions_spare\" label=\"Emissioni di CO2 evitate\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"equivalent_trees\" label=\"Alberi equivalenti\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"irradiance\" label=\"Irradianza\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"temperature\" label=\"Temperatura\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"wind\" label=\"Vento\"></asyncdisplay>\n\t\t\t<asyncdisplay propertyname=\"energy\" label=\"Energia\"></asyncdisplay>\n\t\t</div>\n\t</div>\n</div>\n<script src=\"applications/" + newId + "/" + newId + ".js\"></script>";
            var js = "var app = angular.module(\"ApioApplication" + newId + "\", [\"apioProperty\"]);\napp.controller(\"defaultController\", [\"$scope\", \"currentObject\", function ($scope, currentObject) {\n\tconsole.log(\"Sono il defaultController e l'oggetto è\");\n\tconsole.log(currentObject.get());\n\t$scope.object = currentObject.get();\n\n\tdocument.getElementById(\"ApioApplicationContainer\").classList.add(\"fullscreen\");\n}]);\n\nsetTimeout(function () {\n\tangular.bootstrap(document.getElementById(\"ApioApplication" + newId + "\"), [\"ApioApplication" + newId + "\"]);\n}, 10);";
            var mongo = "{\n\t\"name\" : \"" + $scope.newName + "\",\n\t\"objectId\" : \"" + newId + "\",\n\t\"protocol\" : \"l\",\n\t\"address\" : \"" + newId + "\",\n\t\"properties\" : {\n\t\t\"kwp\" : \"0\",\n\t\t\"instat_power\" : \"0\",\n\t\t\"day_production\" : \"0\",\n\t\t\"total_production\" : \"0\",\n\t\t\"installation_date\" : \"0\",\n\t\t\"oil_litres_spare\" : \"0\",\n\t\t\"co2_emissions_spare\" : \"0\",\n\t\t\"equivalent_trees\" : \"0\",\n\t\t\"irradiance\" : \"0\",\n\t\t\"temperature\" : \"0\",\n\t\t\"wind\" : \"0\",\n\t\t\"energy\" : \"0\"\n\t},\n\t\"notifications\" : {},\n\t\"db\" : {}\n}";
            var makefile = "BOARD_TAG = General\nARDUINO_PORT = /dev/ttyACM0\nARDUINO_LIBS = \nARDUINO_DIR = /usr/share/arduino\ninclude ../Arduino.mk\n";
            var icon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAAAtFJREFUeAHt0IEAAAAAw6D5Ux/khVBhwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwIABAwYMGDBgwICBr4EBceYAAZGozkYAAAAASUVORK5CYII=";

            $http.post("/apio/database/createNewApioApp", {
                object: dao,
                ino: ino,
                html: html,
                js: js,
                mongo: mongo,
                makefile: makefile,
                icon: icon
            }).success(function () {
                alert("Oggetto creato con successo");
                $window.location.reload();
            }).error(function (err) {
                console.log("An error has occurred while saving the object: ", err);
            });
            $scope.newInstallationFlag = false;
        }).error(function (error) {
            console.log("An error has occurred while getting the maximum id: ", error);
        });
    };

    $scope.newInstallationTrigger = function () {
        $scope.newInstallationFlag = true;
    };
}]);

setTimeout(function () {
    angular.bootstrap(document.getElementById("ApioApplication3"), ["ApioApplication3"]);
}, 10);