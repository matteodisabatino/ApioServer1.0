var app = angular.module("ApioApplication13", ["apioProperty"]);
app.controller("defaultController",["$scope", "currentObject", function($scope, currentObject){
	console.log("Sono il defaultController e l'oggetto è");
	console.log(currentObject.get());
	$scope.object = currentObject.get();

    document.getElementById("ApioApplicationContainer").classList.add("fullscreen");
}]);

setTimeout(function(){
	angular.bootstrap(document.getElementById("ApioApplication13"), ["ApioApplication13"]);
},10);